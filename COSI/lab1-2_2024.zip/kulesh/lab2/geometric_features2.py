import numpy as np


def square(labels_array, image):
    return {label: np.sum(image == label) for label in labels_array}


def perimeter(labels_array, image):
    perimeters = {label: 0 for label in labels_array}
    padded_image = np.pad(image, 1, mode='constant')  # Padding to avoid border issues

    for label in labels_array:
        if label != 0:  # Skip background
            mask = padded_image == label
            for y in range(1, image.shape[0] + 1):
                for x in range(1, image.shape[1] + 1):
                    if mask[y, x]:
                        # Check 4-connectivity (up, down, left, right)
                        if not mask[y, x-1] or not mask[y, x+1] or not mask[y-1, x] or not mask[y+1, x]:
                            perimeters[label] += 1
    return perimeters


def compactness(squares, perimeters):
    return {label: (perimeters[label] ** 2) / squares[label] for label in squares}


def mass_center(labels, image):
    mass_centers = {}
    for label in labels:
        if label != 0:  # Skip background
            # Create a boolean mask for the current label
            mask = image == label
            # Calculate the center of mass for the current label
            y_indices, x_indices = np.nonzero(mask)
            x_center = x_indices.sum() / mask.sum()
            y_center = y_indices.sum() / mask.sum()
            mass_centers[label] = (x_center, y_center)
    return mass_centers


def central_moment(i, j, x_central, y_central, x_indices, y_indices):
    x_moment = (x_indices - x_central) ** i if i > 0 else 1
    y_moment = (y_indices - y_central) ** j if j > 0 else 1
    return (x_moment * y_moment).sum()


def elongation(labels_array, image, mass_centers):
    elongations = {}

    for label in labels_array:
        if label != 0:  # Skip background
            x_mass_center, y_mass_center = mass_centers[label]
            y_indices, x_indices = np.nonzero(image == label)
            m20 = central_moment(2, 0, x_mass_center, y_mass_center, x_indices, y_indices)
            m02 = central_moment(0, 2, x_mass_center, y_mass_center, x_indices, y_indices)
            m11 = central_moment(1, 1, x_mass_center, y_mass_center, x_indices, y_indices)
            root = np.sqrt((m20 - m02) ** 2 + 4 * (m11 ** 2))
            elongations[label] = (m20 + m02 + root) / (m20 + m02 - root)

    return elongations


