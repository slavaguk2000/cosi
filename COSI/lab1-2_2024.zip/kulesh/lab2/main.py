import numpy as np
import matplotlib.pyplot as plt
from PIL import Image, ImageFilter
from matplotlib.colors import ListedColormap
import matplotlib

from kulesh.lab2.geometric_features2 import square, perimeter, compactness, mass_center, elongation

clusters_count = 4
initial_image_name = 'easy/P0001471.jpg'
min_square = 200
show_clustering_process = True
custom_centroids_initialization = True


def get_colors_keys(colors_keys_count: int):
    return np.array(range(1, 256, 254 // (colors_keys_count - 1)))


clusters_colors_keys = get_colors_keys(clusters_count)

original_cmap = matplotlib.colormaps['jet']


def modify_colormap(original_cmap, background_color):
    new_cmap_colors = original_cmap(np.arange(original_cmap.N))
    new_cmap_colors[0, :3] = background_color
    return ListedColormap(new_cmap_colors)


modified_cmap = modify_colormap(original_cmap, background_color=[1, 1, 1])


def get_labels_to_color_map(unique_labels):
    colors_keys = get_colors_keys(len(unique_labels))
    labels_map = dict()
    for i, label in enumerate(unique_labels):
        labels_map[label] = colors_keys[i]

    return labels_map


def change_labels_by_labels_map(image, labels_map):
    new_image = np.zeros_like(image, dtype=np.uint8)
    for y in range(image.shape[0]):
        for x in range(image.shape[1]):
            label = image[y, x]
            if label != 0:
                new_image[y, x] = labels_map[label]

    return new_image


def show_image(image):
    plt.clf()
    plt.imshow(image, cmap=modified_cmap)
    plt.colorbar()
    plt.show()


def find_root(equivalences, label):
    root = label
    while equivalences[root] != root:
        root = equivalences[root]
    return root


def flatten_equivalences(equivalences):
    for label in equivalences:
        root = find_root(equivalences, label)
        while label != root:
            next_label = equivalences[label]
            equivalences[label] = root
            label = next_label
    return equivalences


def filter_small_objects(labeled_image, min_square):
    for label in np.unique(labeled_image):
        object_mask = labeled_image == label
        if np.sum(object_mask) < min_square:
            labeled_image[object_mask] = 0
    return labeled_image


def mark_objects(image_array):
    labeled_image = np.zeros_like(image_array, dtype=np.int32)
    next_label = 1
    label_equivalences = {}

    for y in range(image_array.shape[0]):
        for x in range(image_array.shape[1]):
            if image_array[y, x] != 0:  # Foreground pixel
                neighbors = [
                    labeled_image[y, x-1] if x > 0 else 0,
                    labeled_image[y-1, x] if y > 0 else 0
                ]
                neighbors = [label for label in neighbors if label != 0]

                if neighbors:
                    min_label = min(neighbors)
                    labeled_image[y, x] = min_label

                    for label in neighbors:
                        if label != min_label:
                            root_label = find_root(label_equivalences, label)
                            min_root_label = find_root(label_equivalences, min_label)
                            if root_label != min_root_label:
                                label_equivalences[root_label] = min_root_label
                else:
                    labeled_image[y, x] = next_label
                    label_equivalences[next_label] = next_label
                    next_label += 1

    # Flatten equivalences
    label_equivalences = flatten_equivalences(label_equivalences)

    # Apply flattened equivalences
    for y in range(image_array.shape[0]):
        for x in range(image_array.shape[1]):
            if labeled_image[y, x] in label_equivalences:
                labeled_image[y, x] = label_equivalences[labeled_image[y, x]]

    filtered_image = filter_small_objects(labeled_image, min_square)

    labels_to_color_map = get_labels_to_color_map(np.unique(filtered_image)[1:])

    return change_labels_by_labels_map(filtered_image, labels_to_color_map)


def binarize_image(image, threshold):
    return (np.array(image) > threshold).astype(np.uint8) * 255


def erosion(image, kernel_size=3):
    kernel = np.full((kernel_size, kernel_size), 255, np.uint8)
    padding = kernel_size // 2
    image_padded = np.pad(image, padding, mode='constant', constant_values=0)

    eroded_image = np.zeros_like(image)
    for y in range(image.shape[0]):
        for x in range(image.shape[1]):
            if np.all(image_padded[y:y+kernel_size, x:x+kernel_size] == kernel):
                eroded_image[y, x] = 255
    return eroded_image


def dilation(image, kernel_size=3):
    kernel = np.full((kernel_size, kernel_size), 255, np.uint8)
    padding = kernel_size // 2
    image_padded = np.pad(image, padding, mode='constant', constant_values=0)

    dilated_image = np.zeros_like(image)
    for y in range(image.shape[0]):
        for x in range(image.shape[1]):
            if np.any(image_padded[y:y+kernel_size, x:x+kernel_size] == kernel):
                dilated_image[y, x] = 255
    return dilated_image


def show_info_on_image(
    labels,
    image,
    squares,
    perimeters,
    compactnesses,
    mass_centers,
    elongations
):
    fig, ax = plt.subplots()
    ax.imshow(image, cmap=modified_cmap)

    j = 0
    for label in labels:
        j += 1
        x0, y0 = mass_centers[label]
        ax.plot(x0, y0, '.g', markersize=10)

        ax.annotate(f'Obj {j}: S: {squares[label]}, P: {perimeters[label]}, C: {compactnesses[label]:.2f}, '
                    f'El: {elongations[label]:.2f}', xy=(x0, y0))

    plt.show()


def remove_outliers(data):
    Q1 = np.percentile(data, 25, axis=0)
    Q3 = np.percentile(data, 75, axis=0)
    IQR = Q3 - Q1

    lower_bound = Q1 - 1.5 * IQR
    upper_bound = Q3 + 1.5 * IQR

    mask = np.all((data >= lower_bound) & (data <= upper_bound), axis=1)
    return data[mask]


def plot_clusters(data, labels, centroids):
    k = len(centroids)
    colors = plt.cm.get_cmap('rainbow', k)

    for i in range(k):
        cluster_points = data[labels == i]
        plt.scatter(cluster_points[:, 0], cluster_points[:, 1], color=colors(i), label=f'Cluster {i}')
        plt.scatter(centroids[i, 0], centroids[i, 1], color=colors(i), marker='o', s=100)
        # for j, point in enumerate(cluster_points):
        #     plt.text(point[0], point[1], str(j), fontsize=9)

    plt.xlabel('Parameter 1')
    plt.ylabel('Parameter 2')
    plt.title('k-medians Clustering')

    plt.xscale('log')
    plt.yscale('log')

    plt.legend()
    plt.show()


def initialize_centroids(data, k):
    if k < 2:
        raise ValueError("too small k")

    if len(np.unique(data, axis=0)) < k:
        raise ValueError("Not enough unique data points to initialize k centroids")

    sum_data = np.sum(data, axis=1)
    min_index = np.argmin(sum_data)
    max_index = np.argmax(sum_data)

    centroids_indices = [min_index, max_index]

    if k > 2:
        min_val = sum_data[min_index]
        max_val = sum_data[max_index]
        step = (max_val - min_val) / (k - 1)

        for i in range(1, k - 1):
            target_val = min_val + i * step
            closest_index = np.argmin(np.abs(sum_data - target_val))
            centroids_indices.append(closest_index)

    unique_indices = list(set(centroids_indices))

    while len(unique_indices) < k:
        additional_indices = np.random.choice(data.shape[0], k - len(unique_indices), replace=False)
        unique_indices.extend(additional_indices)
        unique_indices = list(set(unique_indices))

    centroids = data[unique_indices, :]

    return centroids


def k_medians(data, k, max_iter=100):
    if data.shape[0] < k:
        raise ValueError("The number of data points must be at least k")

    centroids = initialize_centroids(data, k) if (custom_centroids_initialization and k > 2) else \
        data[np.random.choice(data.shape[0], k, replace=False), :]

    centroids_history = [centroids]

    ptp_data = np.ptp(remove_outliers(data), axis=0)

    for iteration in range(max_iter):
        print(f"ptp: {ptp_data}")
        # Step 2: Assign each data point to the closest centroid
        labels = np.array([
            np.argmin([np.sum(np.abs(point - centroid) / ptp_data) for centroid in centroids])
            for point in data
        ])

        for point in data:
            for centroid in centroids:
                print(f"p: {point}, c: {centroid}, dif: {np.abs(point - centroid)}, ndif: {np.abs(point - centroid) / ptp_data} ")

        # Step 3: Update centroids to be the median of points assigned to them
        centroids = np.array([np.median(data[labels == i], axis=0)
            for i in range(k)
        ])

        if show_clustering_process:
            plot_clusters(data, labels, centroids)

        # Check for convergence (if centroids do not change)
        matches = sum([np.array_equal(centroids, old_centroids) for old_centroids in centroids_history[-10:]])

        if matches >= 5:
            break

        centroids_history.append(centroids)

    return centroids, labels


def make_clustering_image(unique_labels, marked_image, clusters_res):
    labels_map = dict()
    for i, label in enumerate(unique_labels):
        labels_map[label] = clusters_colors_keys[clusters_res[i]]

    return change_labels_by_labels_map(marked_image, labels_map)


def main():
    initial_image = Image.open(initial_image_name)
    image = initial_image.copy().convert("L") #grayscale

    show_image(image)

    binarization_threshold = 200

    # initial binarization
    binarized_image = binarize_image(image, binarization_threshold)

    show_image(binarized_image)

    # filtering for noise reduction
    new_image = image.filter(ImageFilter.MedianFilter(size=7))

    binarized_image = binarize_image(new_image, binarization_threshold)

    show_image(binarized_image)

    eroded_image = erosion(binarized_image, kernel_size=3)

    show_image(eroded_image)

    dilated_image = dilation(eroded_image, kernel_size=3)

    show_image(dilated_image)

    # mark objects
    marked_image = mark_objects(np.array(dilated_image))

    unique_labels = np.unique(marked_image)[1:]

    squares = square(unique_labels, marked_image)
    perimeters = perimeter(unique_labels, marked_image)
    compactnesses = compactness(squares, perimeters)
    mass_centers = mass_center(unique_labels, marked_image)
    elongations = elongation(unique_labels, marked_image, mass_centers)

    show_info_on_image(
        unique_labels,
        marked_image,
        squares,
        perimeters,
        compactnesses,
        mass_centers,
        elongations
    )

    features = np.array([[compactnesses[label], elongations[label]] for label in unique_labels])
    _, clusters_res = k_medians(features, clusters_count)

    clustering_image = make_clustering_image(unique_labels, marked_image, clusters_res)

    show_image(clustering_image)


if __name__ == '__main__':
    main()
