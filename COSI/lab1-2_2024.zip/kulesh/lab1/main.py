import numpy as np
from matplotlib import pyplot as plt, image as mpimg


def harmonic_mean_filter(image, ksize=3):
    pad_size = ksize // 2
    padded_image = np.pad(image, ((pad_size, pad_size), (pad_size, pad_size), (0, 0)), mode='edge')

    filtered_image = np.zeros_like(image)

    for i in range(pad_size, padded_image.shape[0] - pad_size):
        for j in range(pad_size, padded_image.shape[1] - pad_size):
            # Extracting the neighborhood of the pixel
            neighborhood = padded_image[i - pad_size:i + pad_size + 1, j - pad_size:j + pad_size + 1]

            # Applying the harmonic mean on the neighborhood
            harmonic_mean = np.zeros(3)
            for channel in range(3):
                # Это контекстный менеджер, который игнорирует предупреждения, связанные с делением на ноль и другими невалидными операциями внутри блока кода.
                with np.errstate(divide='ignore', invalid='ignore'):
                    # Avoid division by zero using a mask
                    # Создаётся маска, которая будет равна True, если значение пикселя больше 0, и False в противном случае.
                    mask = neighborhood[:, :, channel] > 0

                    # Вычисляется гармоническое среднее для текущего канала. Это делается путём суммирования значений маски и деления её на сумму обратных значений окрестности пикселей. Оператор ~mask обращает маску, так что деление на ноль не происходит (вместо него добавляется ноль).
                    harmonic_mean[channel] = np.sum(mask) / np.sum(1 / (neighborhood[:, :, channel] + ~mask))

            # Assigning the harmonic mean value to the center pixel
            filtered_image[i - pad_size, j - pad_size] = np.clip(harmonic_mean, 0, 255)

    return filtered_image


def median_filter(image, ksize=3):
    pad_size = ksize // 2
    padded_image = np.pad(image, ((pad_size, pad_size), (pad_size, pad_size), (0, 0)), mode='edge')

    # Preparing the output image
    filtered_image = np.zeros_like(image)

    # Iterating over every pixel in the image
    for i in range(pad_size, padded_image.shape[0] - pad_size):
        for j in range(pad_size, padded_image.shape[1] - pad_size):
            # Extracting the neighborhood of the pixel
            neighborhood = padded_image[i - pad_size:i + pad_size + 1, j - pad_size:j + pad_size + 1]

            # Applying the median filter on the neighborhood
            for channel in range(3):
                filtered_image[i - pad_size, j - pad_size, channel] = np.median(neighborhood[:, :, channel])

    return filtered_image


def negative(image):
    for string in image:
        for pixel in string:
            for i in range(3):
                pixel[i] = 255 - pixel[i]


def linear_contrast(image):
    g_min, g_max = 0, 255
    f_min, f_max = get_f(image)
    a = (g_max - g_min)/(f_max - f_min)
    b = (g_min + g_max - a * (f_min + f_max)) / 2
    return np.clip(a * image + b, 0, 255).astype(np.uint8)


def get_f(image, lower_percentile=5, upper_percentile=95):
    brightness_values = [get_brightness(pix) for string in image for pix in string]

    f_min = np.percentile(brightness_values, lower_percentile)
    f_max = np.percentile(brightness_values, upper_percentile)

    return f_min, f_max


def draw_image(image):
    plt.imshow(image)
    plt.show()


def get_brightness(pixel):
    return int(0.3 * pixel[0] + 0.59 * pixel[1] + 0.11 * pixel[2])


def draw_histogram(image):
    xarray = np.zeros(256)
    for string in image:
        for pix in string:
            xarray[get_brightness(pix)] += 1
    plt.title("Brightness Histogram")
    plt.xlabel("Brightness")
    plt.ylabel("Number of Pixels")
    plt.plot(xarray)
    plt.show()


def show_image_data(image):
    draw_image(image)
    draw_histogram(image)


def cover_file_name(file):
    return "images/" + file + ".jpg"


if __name__ == '__main__':
    print("input file: ")
    image = np.asarray(mpimg.imread(cover_file_name(input()))).copy()
    show_image_data(image)

    chosen_process = 0
    while chosen_process < 1 or chosen_process > 4:
        print("Choose process: \n1. Harmonic mean filter\n2. Median filter\n3. Negative\n4. Contrast")
        try:
            chosen_process = (int(input()))
        except:
            pass

    if chosen_process == 3:
        negative(image)
        show_image_data(image)
    elif chosen_process == 4:
        image = linear_contrast(image)
        show_image_data(image)
    else:
        mask_size = 3
        print("Enter mask size or use default(3):")
        try:
            mask_size = (int(input()))
        except:
            pass
        print(f"Using mask size {mask_size}...")

        image = harmonic_mean_filter(image, mask_size) if chosen_process == 1 else median_filter(image, mask_size)
        show_image_data(image)

    print("output file: ")
    mpimg.imsave(cover_file_name(input()), image)
